python main.py

